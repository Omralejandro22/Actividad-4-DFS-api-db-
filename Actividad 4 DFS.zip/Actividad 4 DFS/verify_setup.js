const axios = require('axios');

const API_URL = 'http://localhost:5000/api';

async function testAPI() {
    try {
        console.log('--- Testing Auth ---');

        let adminToken;
        let userToken;

        // 1. Register Admin
        console.log('Registering Admin...');
        try {
            const adminRes = await axios.post(`${API_URL}/auth/register`, {
                username: 'adminUser',
                password: 'adminPassword123',
                role: 'admin'
            });
            adminToken = adminRes.data.token;
            console.log('Admin Registered:', adminRes.data.username);
        } catch (error) {
            if (error.response && error.response.status === 400) {
                console.log('Admin already exists, logging in...');
                const loginRes = await axios.post(`${API_URL}/auth/login`, {
                    username: 'adminUser',
                    password: 'adminPassword123'
                });
                adminToken = loginRes.data.token;
                console.log('Admin Logged In');
            } else {
                console.error('Admin Register Error:', error.message);
            }
        }

        // 2. Register User
        console.log('Registering User...');
        try {
            const userRes = await axios.post(`${API_URL}/auth/register`, {
                username: 'regularUser',
                password: 'userPassword123',
                role: 'user'
            });
            userToken = userRes.data.token;
            console.log('User Registered:', userRes.data.username);
        } catch (error) {
            if (error.response && error.response.status === 400) {
                console.log('User already exists, logging in...');
                const loginRes = await axios.post(`${API_URL}/auth/login`, {
                    username: 'regularUser',
                    password: 'userPassword123'
                });
                userToken = loginRes.data.token;
                console.log('User Logged In');
            } else {
                console.error('User Register Error:', error.message);
            }
        }

        console.log('\n--- Testing Products ---');

        // 3. Admin create product
        console.log('Admin creating product...');
        let productId;
        try {
            const productRes = await axios.post(`${API_URL}/products`, {
                name: 'Test Product',
                price: 100,
                stock: 10
            }, {
                headers: { Authorization: `Bearer ${adminToken}` }
            });
            productId = productRes.data._id;
            console.log('Product Created:', productRes.data.name);
        } catch (error) {
            console.error('Create Product Error:', error.response ? error.response.data : error.message);
        }

        if (!productId) {
            console.error('Failed to create product, aborting subsequent tests.');
            return;
        }

        // 4. User update stock (Allowed)
        console.log('User updating stock...');
        try {
            const updateStockRes = await axios.put(`${API_URL}/products/${productId}`, {
                stock: 20
            }, {
                headers: { Authorization: `Bearer ${userToken}` }
            });
            console.log('Stock Updated:', updateStockRes.data.stock);
        } catch (error) {
            console.error('Update Stock Error:', error.response ? error.response.data : error.message);
        }

        // 5. User update price (Denied)
        console.log('User updating price (Should Fail)...');
        try {
            await axios.put(`${API_URL}/products/${productId}`, {
                price: 200
            }, {
                headers: { Authorization: `Bearer ${userToken}` }
            });
            console.error('CRITICAL: User was able to update price!');
        } catch (error) {
            if (error.response && error.response.status === 403) {
                console.log('Success: User denied price update.');
            } else {
                console.log('Update Price Error (Unexpected):', error.response ? error.response.data : error.message);
            }
        }

        // 6. Admin delete product
        console.log('Admin deleting product...');
        try {
            await axios.delete(`${API_URL}/products/${productId}`, {
                headers: { Authorization: `Bearer ${adminToken}` }
            });
            console.log('Product Deleted');
        } catch (error) {
            console.error('Delete Product Error:', error.response ? error.response.data : error.message);
        }

    } catch (error) {
        console.error('Global Error:', error.message);
    }
}

testAPI();
