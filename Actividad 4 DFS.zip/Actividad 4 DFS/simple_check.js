const mongoose = require('mongoose');

// Hardcode URI to avoid dotenv issues for now, based on previous .env file view
const MONGO_URI = "mongodb://localhost:27017/inventory_db";

const userSchema = new mongoose.Schema({
    username: String,
    password: String,
    role: String
}, { strict: false }); // Strict false to read whatever is there

const User = mongoose.model('User', userSchema);

async function run() {
    try {
        await mongoose.connect(MONGO_URI);
        console.log('Connected!');

        const users = await User.find({});
        console.log('Users found:', users.length);

        users.forEach(u => {
            console.log(`User: ${u.username}, Role: ${u.role}, Pwd: ${u.password ? u.password.substring(0, 15) : 'NONE'}...`);
        });

        await mongoose.disconnect();
    } catch (e) {
        console.error(e);
    }
}

run();
